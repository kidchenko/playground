nota = -1
while nota < 0 or nota > 10:
    nota = float(input('Digite o valor da nota entre 0 e 10:'))
print(nota)
